package task.Utility;

/**
 * The Landscape is a tile based mesh containing the Coordinate System
 * The main struct is held by the Coordinae System
 * This class adds utility methods which do not fit into the Coordinate System
 * @author uxofb
 * @version 0.142856...
 */
public class Landscape {

    private CoordinateSystem coordinateSystem;
    private boolean initialized;
    private String[][] landscape;
    private int height;
    private int width;

    /**
     * Constructor Method for the Landscape
     * @param input 2D String Array with suggestive String of lenth one
     * @param height Positive Integer > 0
     * @param width Positive Integer > 0
     */
    public Landscape(String[][] input, int height, int width) {

        this.landscape = input;
        this.height = height;
        this.width = width;
        
        if (landscape != null) {
            coordinateSystem = new CoordinateSystem(width, height, landscape);
            coordinateSystem.initNeighbours();
            if (check()) {
                this.initialized = true;
            }
        }
    }

    /**
     * Get method for landscape symbols
     * @return 2D StringArray of Strings usually with lengths one
     */
    public String[][] getLayout() {
        String[][] output = new String[height][width];
        for (Coordinate coordinate : getLandscape()) {
            output[coordinate.getPos().getY()][coordinate.getPos().getX()] = coordinate.getSymbol();
        }

        return output;
    }
    
    /**
     * Get method for height attribute
     * @return Positive integer
     */
    public int getHeight() {
        return this.height;
    }

    /**
     * Get method for width attribute
     * @return Positive integer
     */
    public int getWidth() {
        return this.width;
    }

    /**
     * Get Method for the Landscape
     * @return Array of Coordinates in the Landscape, conveniently sorted from top left to bottom right
     */
    public Coordinate[] getLandscape() {
        return coordinateSystem.getCoordinates();
    }
    
    /**
     * Get Method for the Symbol at a specific point
     * @param pos Vector2D object with positive posiiton
     * @return String, usually with lengths one
     */
    public Coordinate getAtPos(Vector2D pos) {
        return coordinateSystem.getCoordAt(pos);
    }

    /**
     * Get Method for the initialized attribute
     * @return Either true or false
     */
    public boolean isInitialized() {
        return this.initialized;
    }

    /**
     * Setter Method for a symbol at a secifiv position
     * @param pos Vector2D object with positive position
     * @param value String with suggestive length one
     */
    public void setAtPos(Vector2D pos, String value) {
        coordinateSystem.setCoordAt(pos, value);
    }

    /**
     * Checks if the given Input meets all the Landscape criteria
     * @return Either true or false
     */
    public boolean check() {
        int countR = 0;
        int countx = 0;
        int countX = 0;

        for (Coordinate coordinate : coordinateSystem.getCoordinates()) {
            if (coordinate.getSymbol().equals("R")) {
                countR++;
            }
            if (coordinate.getSymbol().equals("x")) {
                countx++;
            }
            if (coordinate.getSymbol().equals("X")) {
                countX++;
            }
        }
        
        return ((countR == 1 && countx == 1 && countX == 0) || (countR == 0 && countx == 0 && countX == 1));
    }

    @Override
    public String toString() {
        String output = "";
        int counter = 0;
        for (Coordinate coordinate : coordinateSystem.getCoordinates()) {
            output += coordinate.getSymbol();
            counter++;
            if (counter % coordinateSystem.getWidth() == 0) {
                output += System.lineSeparator();
            }
        }
        return output.substring(0, output.length() - System.lineSeparator().length());
    }
}
