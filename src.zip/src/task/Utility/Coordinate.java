package task.Utility;

/**
 * A Coordinate describes a point in a karthesian Coordinate System with a Specific Symbol
 * for visual representation
 * @author uxofb
 * @version 22/7
 */
public class Coordinate {
    
    private String symbol;
    private final Vector2D pos;
    private Coordinate up;
    private Coordinate down;
    private Coordinate left;
    private Coordinate right;
    private Coordinate pointer;

    /**
     * Constructor Method of the Coordinate
     * @param value String with suggestive length one
     * @param pos Vetor2D object with positive positions
     */
    public Coordinate(String value, Vector2D pos) {
        this.symbol = value;
        this.pos = pos;
    }

    /**
     * Get Method for Symbol Attribute
     * @return String, usually of length one
     */
    public String getSymbol() {
        return symbol;
    }

    /**
     * Get Method for Position
     * @return Vector2D object, has positive position
     */
    public Vector2D getPos() {
        return pos;
    }

    /**
     * Setter Method for the Symbol of the Coordinate
     * @param value String with suggestive length one
     */
    public void setSymbol(String value) {
        this.symbol = value;
    }

    /**
     * Get Method for up-neighbour
     * @return Coordinate type object, can return null
     */
    public Coordinate up() {
        return up;
    }

    /**
     * Get Method for down-neighbour
     * @return Coordinate type object, can return null
     */
    public Coordinate down() {
        return down;
    }

    /**
     * Get Method for left-neighbour
     * @return Coordinate type object, can return null
     */
    public Coordinate left() {
        return left;
    }

    /**
     * Get Method for right-neighbour
     * @return Coordinate type object, can return null
     */
    public Coordinate right() {
        return right;
    }

    /**
     * Get Method for all Neighbours
     * @return Coordinate Array of length 4, can contian null
     */
    public Coordinate[] getNeighbours() {
        Coordinate[] neighbours = {up, down, left, right};
        return neighbours;
    }

    /**
     * Get method for the pointer
     * @return Coordinate with positive position
     */
    public Coordinate getPointer() {
        return pointer;
    }

    /**
     * Set method for the top neighbour
     * @param coordinate Coordinate type object
     */
    public void setUp(Coordinate coordinate) {
        this.up = coordinate;
    }

    /**
     * Set method for the bottom neighbour
     * @param coordinate Coordinate type object
     */
    public void setDown(Coordinate coordinate) {
        this.down = coordinate;
    }

    /**
     * Set method for the left neighbour
     * @param coordinate Coorinate type object
     */
    public void setLeft(Coordinate coordinate) {
        this.left = coordinate;
    }

    /**
     * Set method for the right neighbour
     * @param coordinate Coordinate type object
     */
    public void setRight(Coordinate coordinate) {
        this.right = coordinate;
    }

    /**
     * Set method for the pointer attribute
     * @param coordinate Coordinate, usually a neighbour Coordinate
     */
    public void setPointer(Coordinate coordinate) {
        this.pointer = coordinate;
    }

    /**
     * Calculates the distance to a specific point
     * @param coordinate Coordinate to measure the distance to
     * @return Double
     */
    public double distanceTo(Coordinate coordinate) {
        return pos.distanceTo(coordinate.pos);
    }

    /**
     * Calculates a value based on the relative position of the start to the target point
     * @param start Coordinate of the starting point
     * @param target Coordinate of the target point
     * @return Double
     */
    public double calculateValue(Coordinate start, Coordinate target) {
        return distanceTo(start) + distanceTo(target) * 2;
    }

    @Override
    public String toString() {
        return (this.pos.toString() + ", " + this.symbol);
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Coordinate) {
            Coordinate coord = (Coordinate) obj;
            return (this.pos.equals(coord.pos) && this.symbol.equals(coord.symbol));
        }
        return false;
    }
}
