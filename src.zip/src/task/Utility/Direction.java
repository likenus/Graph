package task.Utility;

/**
 * Enum for directional constants
 * @author uxofb
 * @version ,
 */
public enum Direction  {
    /**
     * The direction up
     */
    UP("up"),

    /**
     * The direction down
     */
    DOWN("down"),

    /**
     * The direction left
     */
    LEFT("left"),

    /**
     * The direction right
     */
    RIGHT("right");

    private final String direction;

    /*Package private*/ Direction(String direction) {
        this.direction = direction;
    }

    /**
     * Get Method for direction String
     * @return String, cant be empty
     */
    public String getDirection() {
        return direction;
    }
}
