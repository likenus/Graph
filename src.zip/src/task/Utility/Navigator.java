package task.Utility;

import java.util.LinkedList;
import java.util.List;

/**
 * The Naigator class is responsible for the pathfinding algorithm
 * (Functions similarly to the A* algorithm)
 * @author uxofb
 * @version A*
 */
public class Navigator {

    private final String[] nonWalkables;

    private Coordinate start;
    private Coordinate target;
    private Coordinate closestCoord;
    private boolean pathFound = false;

    private List<Direction> directions = new LinkedList<>();
    private List<Coordinate> openList = new LinkedList<>();
    private List<Coordinate> closedList = new LinkedList<>();

    /**
     * Constructor method of the Navigator
     * @param start Coordinate of the starting point
     * @param target Coordinate of the target point
     * @param nonWalkables String-Array constant of non-walkable terrain
     */
    public Navigator(Coordinate start, Coordinate target, String[] nonWalkables) {
        this.start = start;
        this.target = target;
        this.closestCoord = start;
        this.nonWalkables = nonWalkables;

        start.setPointer(null);

        openList.add(start);
    }

    /**
     * This method calculates a path to the target if possible
     * Path is stored internally and can be accessed via getPath()
     * @return Returns true on successful path finding and false when unsuccessful
     */
    public boolean calculatePath() {
        while (!closestCoord.equals(target)) {
            if (openList.size() > 0) {
                scanLists();
            } else {
                pathFound = false;
                return false;
            }
        }
        pathFound = true;
        getDirections();
        return true;
    }

    //Main pathfinding happens here, functions like the A* pathfinding algorithm
    private void scanLists() {
        Coordinate oldClosestCoord = closestCoord;

        for (Coordinate coord : closestCoord.getNeighbours()) {
            if (isAvailable(coord)) {
                openList.add(coord);
                coord.setPointer(closestCoord);
            }
        }

        openList.remove(closestCoord);
        

        for (Coordinate coord : openList) {
            //Get coordinate closest to target
            if (isAvailable(coord) && !coord.equals(closestCoord)
                && coord.calculateValue(start, target) < closestCoord.calculateValue(start, target)) {
                closestCoord = coord;
            }
        }

        if (closestCoord.equals(oldClosestCoord) && openList.size() > 0) {
            closestCoord = openList.get(0);
        }

        closedList.add(oldClosestCoord);
    }

    //When not null, walkable and not in closed list
    private boolean isAvailable(Coordinate coordinate) {
        if (coordinate != null) {
            for (String obstacle : nonWalkables) {
                if (coordinate.getSymbol().equals(obstacle) || closedList.contains(coordinate)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    //Extracts a list of Directions found by the pathfinding algorithm and stores it in directions
    private void getDirections() {
        if (target.getPointer() == null) {
            return;
        }

        Coordinate pointer = target;
        
        while (pointer.getPointer() != null) {
            for (Coordinate coord : pointer.getNeighbours()) {
                if (coord != null && coord.equals(pointer.getPointer())) {
                    if (coord.equals(pointer.down())) {
                        directions.add(0, Direction.UP);
                    } else if (coord.equals(pointer.up())) {
                        directions.add(0, Direction.DOWN);
                    } else if (coord.equals(pointer.left())) {
                        directions.add(0, Direction.RIGHT);
                    } else if (coord.equals(pointer.right())) {
                        directions.add(0, Direction.LEFT);
                    }
                }
            }

            pointer = pointer.getPointer();
        }
    }

    /**
     * This method returns the directions calculated by the path finding algorithm
     * Returns "FAIL" is no path was found
     * @return String, can contain line Separators
     */
    public String getPath() {
        if (pathFound) {
            String output = "PATH " + directions.size() + System.lineSeparator();
            for (Direction d : directions) {
                output += d.getDirection() + System.lineSeparator();
            }

            return output.substring(0, output.length() - System.lineSeparator().length());
        } else {
            return "FAIL";
        }
        
    }

    /**
     * Return the path calculted by the pathfinding algortithm as Direction Array
     * @return Direction Array, can be empty
     */
    public Direction[] getRawPath() {
        if (pathFound) {
            Direction[] path = new Direction[directions.size()];
            for (int i = 0; i < directions.size(); i++) {
                path[i] = directions.get(i);
            }
            return path;

        } else {
            return new Direction[] {};
        }
    }
}
