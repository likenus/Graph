package task.Utility;

/**
 * The Coordinate System holds all Coordinates in a rectangular Karthesian Coordinate System
 * @author uxofb
 * @version 0.0.0
 */
public class CoordinateSystem {
    
    private final int height;
    private final int width;
    private final int size;

    private Coordinate[] coordinates;

    /**
     * Constructor Method of the Coordinate System
     * @param width Positive Integer
     * @param height Positive Integer
     * @param landscape 2D StringArray filled with Strings of suggestive length one
     */
    public CoordinateSystem(int width, int height, String[][] landscape) {
        this.width = width;
        this.height = height;
        this.size = this.width * this.height;

        this.coordinates = new Coordinate[size];

        for (int i = 0; i < size; i++) {
            coordinates[i] = new Coordinate(landscape[i / width][i % width], 
                new Vector2D(i % width, i / width));
        }
    }

    /**
     * Looks for the Coordinate at a specific position in the Coordinate System
     * @param vector Vector2D object
     * @return Returns a Coordinate objecte, can return null when Coordinate was not found
     */
    public Coordinate getCoordAt(Vector2D vector) {
        for (Coordinate coordinate : coordinates) {
            if (coordinate.getPos().equals(vector)) {
                return coordinate;
            }
        }
        return null;
    }

    /**
     * Sets the Symbol of the Coordinate at a specific point in the Coordinate System
     * @param vector Vector2D object with positive positions
     * @param value String, length needs to be one
     */
    public void setCoordAt(Vector2D vector, String value) {
        for (Coordinate coordinate : coordinates) {
            if (coordinate.getPos().equals(vector)) {
                coordinate.setSymbol(value);
                break; //Break to cut unneccesary runtime
            }
        }
    }

    /**
     * This Method sets the neighbours of every Coordinate in the Coordinate System
     * Coordinates can have null as neighbour.
     */
    public void initNeighbours() {
        for (Coordinate coordinate : coordinates) {
            coordinate.setUp(getCoordAt(new Vector2D(coordinate.getPos().getX(), coordinate.getPos().getY() - 1)));
            coordinate.setDown(getCoordAt(new Vector2D(coordinate.getPos().getX(), coordinate.getPos().getY() + 1)));
            coordinate.setLeft(getCoordAt(new Vector2D(coordinate.getPos().getX() - 1, coordinate.getPos().getY())));
            coordinate.setRight(getCoordAt(new Vector2D(coordinate.getPos().getX() + 1, coordinate.getPos().getY())));
        }
    }

    /**
     * Get Methods for all Coordinates in the Coordinate System
     * @return Coordinate Array, convieniently sorted from top left to bottom right
     */
    public Coordinate[] getCoordinates() {
        return coordinates;
    }

    /**
     * Get Method for width
     * @return Positive Integer
     */
    public int getWidth() {
        return width;
    }
}
