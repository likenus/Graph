package task.Utility;

/**
 * Utility class for describing positions
 * @author uxofb
 * @version new Vector2D(0, 0)
 */
public class Vector2D {
    
    private int x;
    private int y;

    /**
     * Constructor method for the Vector2D
     * @param x Integer
     * @param y Integer
     */
    public Vector2D(int x, int y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Get method for the x position
     * @return integer
     */
    public int getX() {
        return x;
    }
 
    /**
     * Get method for the y position
     * @return integer
     */
    public int getY() {
        return y;
    }

    /**
     * Set method for x position
     * @param x Integer
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Set method for the y position
     * @param y Integer
     */
    public void setY(int y) {
        this.y = y;
    }
    
    /**
     * Set method for both x and y positions
     * @param vector Vector2D objet with Integer arguments
     */
    public void set(Vector2D vector) {
        this.x = vector.x;
        this.y = vector.y;
    }

    /**
     * Calculates the distance to a specific point
     * @param vector Vector2D obect to measure the distance to
     * @return Deouble
     */
    public double distanceTo(Vector2D vector) {
        return Math.sqrt(Math.pow(vector.x - this.x, 2) + Math.pow(vector.y - this.y, 2));
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Vector2D) {
            Vector2D vector = (Vector2D) obj;
            return (this.x == vector.x && this.y == vector.y);
        }
        return false;
    }

    @Override
    public String toString() {
        return this.x + " " + this.y;
    }
}
