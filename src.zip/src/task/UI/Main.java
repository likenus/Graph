package task.UI;

/**
 * Main Class containing the main method, called on run
 * @author uxofb
 * @version (o_O)
 */
public class Main {

    /**
     * Main method, called on Run
     * @param args are ignored
     */
    public static void main(String[] args) {
        UserInterface ui = new UserInterface();

        ui.main();
    }
    
}