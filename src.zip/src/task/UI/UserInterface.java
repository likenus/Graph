package task.UI;

import java.util.Scanner;

import task.Classes.Rover;
import task.Utility.Direction;

/**
 * User Interface class, it contains all In- and output
 * @author uxofb
 * @version no
 */
public class UserInterface {

    private boolean landscapeInitialized = false;
    private boolean quit = false;
    private boolean read = false;

    private int height;
    private int width;
    private int counter;
    private String[][] landscape;

    private Scanner scanner = new Scanner(System.in);

    private Rover rover = new Rover();

    /**
     * Main function where all user Input is read
     * All output is also located here
     * This function contains the mainloop
     */
    public void main() {

        //Input-System
        while (!quit) {
            String input = scanner.nextLine();

            String instruction = getCommand(input)[0];
            String arguments = getCommand(input)[1];

            //Case : no landscape has been initialized yet
            if (!landscapeInitialized) {
                switch (instruction) {
                    case "new"  : 
                        if (resetLandscape(arguments)) {
                            read = true; 
                        }
                        break;
                    case "quit" : quit = true;
                        break;
                    default : 
                        if (!read) {
                            break;
                        } else {
                            addToLandscape(input);
                            break;
                        }
                }   
                
            //Case : once a landscape has been initialized
            } else {
                switch (instruction) {
                    case "new" :
                        if (resetLandscape(arguments)) {
                            read = true; 
                        }
                        break;
                    case "quit" : 
                        quit = true; 
                        break;
                    case "debug" : 
                        System.out.println(rover); 
                        break;
                    case "up" :
                        rover.move(Direction.UP, arguments);
                        break;
                    case "down" :
                        rover.move(Direction.DOWN, arguments);
                        break;
                    case "left" :
                        rover.move(Direction.LEFT, arguments);
                        break;
                    case "right" :
                        rover.move(Direction.RIGHT, arguments);
                        break;
                    case "path" :
                        System.out.println(rover.printPath());
                        break;
                    case "debug-path" :
                        System.out.println(rover.pathOnLandscape());
                        break;
                    default : 
                        if (!read) {
                            break;
                        } else {
                            addToLandscape(input);
                            break;
                        }
                }
            }
        }

        scanner.close();
    }

    private boolean resetLandscape(String arguments) {
        if (arguments.split(" ").length == 2) {
            width = intParser(arguments.split(" ")[0]);
            height = intParser(arguments.split(" ")[1]);
            if (width > 0 && height > 0) {
                counter = height;

                landscape = new String[height][width];

                return true;
            }
        }
        read = false;
        return false;
    }

    private void addToLandscape(String input) {
        if (counter > 0) {
            if (isCorrectWidth(input, width)) {
                landscape[height - counter] = convert(input);
                counter--;
            } else {
                read = false;
                throwError();
            }
        } 

        if (counter == 0) {
            rover.drawLandscape(landscape, height, width);
            read = false;

            if (rover.check()) {
                landscapeInitialized = true;
            } else {
                throwError();
            }
        }
    }

    private void throwError() {
        System.out.println("ERROR");
    }

    /**
     * Separates input into command and arguments
     * @param input String
     * @return Array with length 2, first cell contains the command, the second contains the arguments
     */
    private static String[] getCommand(String input) {
        String command = "";
        String arguments = "";
        String temp = "";

        if (!input.isEmpty()) {
            for (int i = 0; i < input.length(); i++) {
                char character = input.charAt(i);

                if (command.isBlank() && character != ' ') {
                    temp += character;
                }
                if (character == ' ' && command.isBlank()) {
                    command += temp;
                }
                if (!command.isBlank()) {
                    arguments += character;
                }
            }

            if (command.isBlank()) {
                command += temp;
            }

            return new String[] {command, arguments.trim()};
        }

        return new String[] {"", ""};
    }

    //Convert String into String[]
    private String[] convert(String input) {
        String[] output = new String[input.length()];

        for (int i = 0; i < input.length(); i++) {
            output[i] = input.charAt(i) + "";
        }
        return output;
    }

    //Check method for catching invalid user input
    private boolean isCorrectWidth(String input, int width) {
        return (input.length() == width);
    }

    private int intParser(String input) {
        int output = 0;
        try {
            output = Integer.parseInt(input);
        } catch (NumberFormatException exception) {
            return 0;
        }
        return output;
    }
}
