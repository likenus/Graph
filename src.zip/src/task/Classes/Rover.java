package task.Classes;

import task.Utility.Landscape;
import task.Utility.Coordinate;
import task.Utility.Navigator;
import task.Utility.Direction;

/**
 * This class models the Rover
 * It contains all utility methods neccessary for the Rover to function
 * @author uxofb
 * @version Wall-E
 */
public class Rover {

    private final String rover = "R";
    private final String[] nonWalkables = {"*", "|", "/", "\\", "_"};
    private final String walkable = " ";
    private final String target = "x";
    private final String onTarget = "X";
    private final String pathTile = ".";
    private String oldSpot;

    private Landscape landscape;
    private Landscape copyOfLandscape;
    private Coordinate location;
    private Coordinate targetLocation;
    private Navigator navi;

    /**
     * Get Method for the current position of the Rover
     * @return Coordinate with positive position
     */
    public Coordinate getLocation() {
        return location;
    }

    /**
     * This Method initialized the Landscape for the rover to traverse in
     * @param inputLandscape 2DStringArray with suggestive Strings of length one
     * @param height Positive Integer > 0
     * @param width Positive Interger > 0
     */
    public void drawLandscape(String[][] inputLandscape, int height, int width) {
        this.landscape = new Landscape(inputLandscape, height, width);

        if (check()) {
            locatePos();
            locateTarget();
        } 
    }

    /**
     * Checks whether the Landscape has been correctly initialized
     * @return Either true or false
     */
    public boolean check() {
        return (landscape.isInitialized() && landscape.check());
    }

    private void locatePos() {
        for (Coordinate coordinate : landscape.getLandscape()) {
            if (coordinate.getSymbol().equals(rover) || coordinate.getSymbol().equals(onTarget)) {
                this.location = coordinate;
                if (coordinate.getSymbol().equals(rover)) {
                    oldSpot = walkable;
                } else if (coordinate.getSymbol().equals(onTarget)) {
                    oldSpot = target;
                }
            }
        }
    }

    private void locateTarget() {
        for (Coordinate coordinate : landscape.getLandscape()) {
            if (coordinate.getSymbol().equals(target) || coordinate.getSymbol().equals(onTarget)) {
                this.targetLocation = coordinate;
            }
        }
    }

    /**
     * Move method of the rover
     * This Method allows the rover to traverse the landscape
     * @param direction Any constant from the Direction Enum
     * @param iterations Positive Integer > 0 as String
     */
    public void move(Direction direction, String iterations) {
        int i;
        Coordinate coord = this.location;

        if (!iterations.isBlank()) {
            try {
                i = Integer.parseInt(iterations);
            } catch (NumberFormatException exception) {
                i = 0;
            }
        } else {
            i = 1;
        }

        for (int j = 0; j < i; j++) {
            switch (direction) {
                case UP :
                    if (isAvailable(location.up())) {
                        coord = location.up();
                    }
                    break;
                case DOWN :
                    if (isAvailable(location.down())) {
                        coord = location.down();
                    }
                    break;
                case LEFT :
                    if (isAvailable(location.left())) {
                        coord = location.left();
                    }
                    break;
                case RIGHT :
                    if (isAvailable(location.right())) {
                        coord = location.right();
                    }
                    break;
                default :
                    coord = location;
                    break;
            }

            landscape.setAtPos(location.getPos(), oldSpot);

            oldSpot = coord.getSymbol();

            if (coord.getSymbol().equals(target)) {
                landscape.setAtPos(coord.getPos(), onTarget);
            } else {
                landscape.setAtPos(coord.getPos(), rover);
            }

            location = coord;
        }
    }

    private boolean isAvailable(Coordinate coordinate) {
        if (coordinate != null) {
            for (String obstacle : nonWalkables) {
                if (coordinate.getSymbol().equals(obstacle)) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    //Calculates the path using the navigator
    private boolean findPath() {
        navi = new Navigator(location, targetLocation, nonWalkables);

        return navi.calculatePath();
    }

    /**
     * Technically a toString Method for the pathfinding algorithm
     * @return Formated String, contains line separators
     */
    public String printPath() {
        findPath();
        return navi.getPath();
    }

    /**
     * Technically a toString for visualizing the path calculated by the pathfinding algorithm
     * @return Formated String containing line separators
     */
    public String pathOnLandscape() {
        if (!findPath()) {
            return "FAIL";
        }
        copyOfLandscape = new Landscape(landscape.getLayout(), landscape.getHeight(), landscape.getWidth());
        Direction[] path = navi.getRawPath();
        Coordinate pointer = location;
        for (Direction d : path) {
            switch(d) {
                case UP :
                    pointer = pointer.up();
                    break;
                case DOWN :
                    pointer = pointer.down();
                    break;
                case LEFT :
                    pointer = pointer.left();
                    break;
                case RIGHT :
                    pointer = pointer.right();
                    break;
                default :
                    break;
            }
            if (!copyOfLandscape.getAtPos(pointer.getPos()).getSymbol().equals(target)) {
                copyOfLandscape.setAtPos(pointer.getPos(), pathTile);
            }

        }
        return copyOfLandscape.toString();
    }

    @Override
    public String toString() {
        return landscape.toString();
    }
}
